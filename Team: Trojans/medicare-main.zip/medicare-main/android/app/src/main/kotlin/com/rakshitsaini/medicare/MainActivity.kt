package com.rakshitsaini.medicare

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
