enum EntryError {
  NameDuplicate,
  NameNull,
  Dosage,
  Type,
  Interval,
  StartTime,
  None,
}
