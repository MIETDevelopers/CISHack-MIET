enum Period {
  Week,
  Month,
  Year,
}
