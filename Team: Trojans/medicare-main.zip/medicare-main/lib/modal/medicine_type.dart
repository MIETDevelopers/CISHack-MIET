enum MedicineType {
  Bottle,
  Pill,
  Syringe,
  Tablet,
  None,
}
