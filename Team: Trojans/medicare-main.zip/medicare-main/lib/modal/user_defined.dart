class User_Defined{
  String userId;
  User_Defined({this.userId});
}

class Email{
  String email;
  Email({this.email});
  String getEmail(){
    return email;
  }
}